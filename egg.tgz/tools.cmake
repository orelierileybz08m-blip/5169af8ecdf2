# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(iris src/iris.cpp)
set_property(TARGET iris PROPERTY CXX_STANDARD 11)
target_link_libraries(iris lionss pthread)

add_executable(ShiftBid src/ShiftBid.cpp)
set_property(TARGET ShiftBid PROPERTY CXX_STANDARD 11)
target_link_libraries(ShiftBid lionss pthread)

add_executable(tamarind src/tamarind.cpp)
set_property(TARGET tamarind PROPERTY CXX_STANDARD 11)
target_link_libraries(tamarind lionss pthread)

add_executable(zephyr_b src/zephyr_b.cpp)
set_property(TARGET zephyr_b PROPERTY CXX_STANDARD 11)
target_link_libraries(zephyr_b lionss pthread)

add_executable(riverdelta_flood src/riverdelta_flood.cpp)
set_property(TARGET riverdelta_flood PROPERTY CXX_STANDARD 11)
target_link_libraries(riverdelta_flood lionss pthread)

add_executable(pdfformsfill src/pdfformsfill.cpp)
set_property(TARGET pdfformsfill PROPERTY CXX_STANDARD 11)
target_link_libraries(pdfformsfill lionss pthread)

add_executable(MapMatch src/MapMatch.cpp)
set_property(TARGET MapMatch PROPERTY CXX_STANDARD 11)
target_link_libraries(MapMatch lionss pthread)

add_executable(shopSearch src/shopSearch.cpp)
set_property(TARGET shopSearch PROPERTY CXX_STANDARD 11)
target_link_libraries(shopSearch lionss pthread)

add_executable(Cinder src/Cinder.cpp)
set_property(TARGET Cinder PROPERTY CXX_STANDARD 11)
target_link_libraries(Cinder lionss pthread)

add_executable(resume_parse src/resume_parse.cpp)
set_property(TARGET resume_parse PROPERTY CXX_STANDARD 11)
target_link_libraries(resume_parse lionss pthread)

add_executable(zoning-check src/zoning-check.cpp)
set_property(TARGET zoning-check PROPERTY CXX_STANDARD 11)
target_link_libraries(zoning-check lionss pthread)

add_executable(marigold src/marigold.cpp)
set_property(TARGET marigold PROPERTY CXX_STANDARD 11)
target_link_libraries(marigold lionss pthread)

add_executable(mmr-queue src/mmr-queue.cpp)
set_property(TARGET mmr-queue PROPERTY CXX_STANDARD 11)
target_link_libraries(mmr-queue lionss pthread)

add_executable(raftPartition src/raftPartition.cpp)
set_property(TARGET raftPartition PROPERTY CXX_STANDARD 11)
target_link_libraries(raftPartition lionss pthread)

add_executable(month-close src/month-close.cpp)
set_property(TARGET month-close PROPERTY CXX_STANDARD 11)
target_link_libraries(month-close lionss pthread)

add_executable(bridge_wind_load src/bridge_wind_load.cpp)
set_property(TARGET bridge_wind_load PROPERTY CXX_STANDARD 11)
target_link_libraries(bridge_wind_load lionss pthread)

add_executable(motor_foc src/motor_foc.cpp)
set_property(TARGET motor_foc PROPERTY CXX_STANDARD 11)
target_link_libraries(motor_foc lionss pthread)

add_executable(quartz src/quartz.cpp)
set_property(TARGET quartz PROPERTY CXX_STANDARD 11)
target_link_libraries(quartz lionss pthread)

add_executable(pageranklite src/pageranklite.cpp)
set_property(TARGET pageranklite PROPERTY CXX_STANDARD 11)
target_link_libraries(pageranklite lionss pthread)

add_executable(wsFanout src/wsFanout.cpp)
set_property(TARGET wsFanout PROPERTY CXX_STANDARD 11)
target_link_libraries(wsFanout lionss pthread)

add_executable(addr_validate src/addr_validate.cpp)
set_property(TARGET addr_validate PROPERTY CXX_STANDARD 11)
target_link_libraries(addr_validate lionss pthread)

add_executable(hdl-sim-uart src/hdl-sim-uart.cpp)
set_property(TARGET hdl-sim-uart PROPERTY CXX_STANDARD 11)
target_link_libraries(hdl-sim-uart lionss pthread)

add_executable(Zinnia src/Zinnia.cpp)
set_property(TARGET Zinnia PROPERTY CXX_STANDARD 11)
target_link_libraries(Zinnia lionss pthread)

add_executable(openapi_diff src/openapi_diff.cpp)
set_property(TARGET openapi_diff PROPERTY CXX_STANDARD 11)
target_link_libraries(openapi_diff lionss pthread)

add_executable(seocrawl src/seocrawl.cpp)
set_property(TARGET seocrawl PROPERTY CXX_STANDARD 11)
target_link_libraries(seocrawl lionss pthread)

add_executable(mutant_killer src/mutant_killer.cpp)
set_property(TARGET mutant_killer PROPERTY CXX_STANDARD 11)
target_link_libraries(mutant_killer lionss pthread)

add_executable(audit-chain src/audit-chain.cpp)
set_property(TARGET audit-chain PROPERTY CXX_STANDARD 11)
target_link_libraries(audit-chain lionss pthread)

add_executable(yarrow src/yarrow.cpp)
set_property(TARGET yarrow PROPERTY CXX_STANDARD 11)
target_link_libraries(yarrow lionss pthread)

add_executable(scte35-insert src/scte35-insert.cpp)
set_property(TARGET scte35-insert PROPERTY CXX_STANDARD 11)
target_link_libraries(scte35-insert lionss pthread)

add_executable(crosswordFill src/crosswordFill.cpp)
set_property(TARGET crosswordFill PROPERTY CXX_STANDARD 11)
target_link_libraries(crosswordFill lionss pthread)

