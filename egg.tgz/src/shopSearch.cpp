// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Index and test 50 queries");
  std::fflush(stdout);
  return lionss_run_workload("shopSearch");
}
