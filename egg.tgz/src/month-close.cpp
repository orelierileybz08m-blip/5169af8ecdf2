// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Post accruals and close period"); }
int main(){
  announce();
  return lionss_run_workload("month-close");
}
