// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Form 5v5 lobbies, max spread 120\n", stdout);
  return lionss_run_workload("mmr-queue");
}
