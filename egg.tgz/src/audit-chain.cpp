// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Append and verify hash chain"); }
int main(){
  announce();
  return lionss_run_workload("audit-chain");
}
