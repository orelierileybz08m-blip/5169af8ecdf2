// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Decode and bin events"); }
int main(){
  announce();
  return lionss_run_workload("marigold");
}
