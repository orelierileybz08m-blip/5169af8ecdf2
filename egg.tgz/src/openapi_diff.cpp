// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Breaking-change report"); }
int main(){
  announce();
  return lionss_run_workload("openapi_diff");
}
