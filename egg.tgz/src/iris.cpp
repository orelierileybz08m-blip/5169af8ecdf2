// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Fit WDRC gains, NAL-NL2\n", stdout);
  return lionss_run_workload("iris");
}
