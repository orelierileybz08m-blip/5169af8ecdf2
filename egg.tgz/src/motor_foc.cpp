// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "FOC step test, 2 kHz");
  std::fflush(stdout);
  return lionss_run_workload("motor_foc");
}
