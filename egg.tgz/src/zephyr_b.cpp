// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Digital twin step response\n", stdout);
  return lionss_run_workload("zephyr_b");
}
