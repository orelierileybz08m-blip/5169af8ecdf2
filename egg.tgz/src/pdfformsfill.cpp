// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Fill AcroForm fields"); }
int main(){
  announce();
  return lionss_run_workload("pdfformsfill");
}
