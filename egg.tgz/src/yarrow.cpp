// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Position-based dynamics, 600 steps\n", stdout);
  return lionss_run_workload("yarrow");
}
