// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Fill with dictionary, backtracking"); }
int main(){
  announce();
  return lionss_run_workload("crosswordFill");
}
